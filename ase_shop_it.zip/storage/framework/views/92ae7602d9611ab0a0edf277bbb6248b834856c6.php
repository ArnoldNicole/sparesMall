<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>ASE ShuleShopIt</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Online Spare Parts Store" name="keywords">
        <meta content="Buy all your Spare parts, Free delivery for select Locations" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400|Source+Code+Pro:700,900&display=swap" rel="stylesheet">

        <!-- CSS Libraries -->
        <link href="<?php echo e(asset('css/frontend/style.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('vendor/font-awesome/css/all.css')); ?>">
        <link href="<?php echo e(asset('/vendor/slick/slick.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/vendor/slick/slick-theme.css')); ?>" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="<?php echo e(asset('/vendor/style.css')); ?>" rel="stylesheet">        
        <script src="<?php echo e(asset('/js/app.js')); ?>" defer></script>
    </head>
    <body>
        <div id="application">
            <?php if(auth()->guard()->check()): ?>
            <main-app :user="<?php echo e(auth()->user()); ?>" :cart='<?php echo json_encode($cart, 15, 512) ?>'>
            </main-app>
            <?php else: ?>
            <main-app :user="false" :cart="false">
            </main-app>
            <?php endif; ?>
        </div>
        <script src="<?php echo e(asset('/vendor/easing/easing.min.js')); ?>" defer></script>
        <script src="<?php echo e(asset('/vendor/slick/slick.min.js')); ?>" defer></script>
        
        <!-- Template Javascript -->
        <script src="<?php echo e(asset('/vendor/main.js')); ?>" defer></script>
    </body>
    </html>
<?php /**PATH E:\sparesMall\resources\views/welcome.blade.php ENDPATH**/ ?>