

<?php $__env->startSection('content'); ?>
<admin-app :user="<?php echo e(auth()->user()); ?>">
	
</admin-app>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sparesMall\resources\views/seller/index.blade.php ENDPATH**/ ?>