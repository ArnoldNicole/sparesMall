<template>
    <div>
        <h1>Terms and Conditions</h1>
    </div>
</template>
<script>
export default {
    mounted(){
        window.scrollTo(0,0)
    }
}
</script>