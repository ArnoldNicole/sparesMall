<template>
    <div class="container-fluid">
      <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1 class="mb30">ASE SCHOOL SHOPIT</h1>
                <p>Welcome to ASE SCHOOL SHOPPIT.

                    We are a company providing all parents with students in bparding schools in both primary and hisgh schools in Kenya a convenient way to shop amidst the COVID 19 Pandemic. 
                    
                    We offer shopping and delivery services for all products to the school. 
                    
                    </p>
                <p>To enjoy our services, choose all the products you need for your student, make your payment, tell us the name of the school and the pupils name.
                    
                   We will deliver within 24 hours and you can always confirm with your teachers.</p>
            </div>
            <div class="col-md-5">
                <div class="about_img">
                    <!-- <img src="images/about.jpg" class="img1 img-responsive" alt="Image"> -->
                    <!-- <img src="images/about.jpg" class="img2 img-responsive" alt="Image"> -->
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="countup_box">
                            <div class="inner">
                                <div class="countup number" data-count="150"></div>
                                <div class="text">Schools</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="countup_box">
                            <div class="inner">
                                <div class="countup number" data-count="100"></div>
                                <div class="text">Deliveries</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="countup_box">
                            <div class="inner">
                                <div class="countup number" data-count="0"></div>
                                <div class="text">Data Bleach</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="countup_box">
                            <div class="inner">
                                <div class="countup number" data-count="10"></div>
                                <div class="text">Partner Shops</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row image-gallery">
            <div class="col-md-3 col-sm-6 mt20 mb20 br2">
                <a href="images/restaurant.jpg" class="hover_effect h_lightbox h_blue">
                    <img src="images/restaurant.jpg" class="img-responsive full_width br2" alt="Image">
                </a>
            </div>
            <div class="col-md-3 col-sm-6 mt20 mb20 br2">
                <a href="images/spa.jpg" class="hover_effect h_lightbox h_blue">
                    <img src="images/spa.jpg" class="img-responsive full_width br2" alt="Image">
                </a>
            </div>
            <div class="col-md-3 col-sm-6 mt20 mb20 br2">
                <a href="images/conference.jpg" class="hover_effect h_lightbox h_blue">
                    <img src="images/conference.jpg" class="img-responsive full_width br2" alt="Image">
                </a>
            </div>
            <div class="col-md-3 col-sm-6 mt20 mb20 br2">
                <a href="images/swimming.jpg" class="hover_effect h_lightbox h_blue">
                    <img src="images/swimming.jpg" class="img-responsive full_width br2" alt="Image">
                </a>
            </div>
        </div>
        <p>Rooms come inclusive of:  </p>
        <ul class="list_menu">
            <li>Free Wifi</li>
            <li>Free Breakfast</li>
            <li>Free Parking</li>
            <li>Laundry Service</li>
            <li>Room Service</li>
        </ul>
        
    </div>
    </div>
</template>