<template>
    <div class="container-fluid">
        <h1 class="h1">Privacy Policy</h1>
    </div>
</template>
<script>
export default {
    mounted(){
        window.scrollTo(0,0)
    }
}
</script>